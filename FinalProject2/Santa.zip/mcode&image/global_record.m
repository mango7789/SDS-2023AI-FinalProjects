clear;clc;
set(gca,'FontName','Times New Rome','FontSize', 14);
policy = readmatrix("choice_type.csv");
reward = readmatrix("reward.csv");
policy = policy(3: end - 1, :);
reward = reward(3: end - 1, :);

policy_1 = find(policy(: , 2) == 1);
policy_2 = find(policy(: , 2) == 2);
policy_3 = find(policy(: , 2) == 3);

figure(1);
hold on;
plot(reward(: , 1), reward(: , 2), "b", LineWidth=1.5);
xlabel("step"); ylabel("Total reward"); title("Total reward over time")
hold off;

figure(2);
hold on;
set(gca,'FontName','Times New Rome','FontSize', 14);

plot(policy_1, ones(length(policy_1), 1), Color='#7E2F8E', Marker='*');
plot(policy_2, 2 * ones(length(policy_2), 1), Color="#EDB120", Marker='.');
plot(policy_3, 3 * ones(length(policy_3), 1), Color="#0072BD", Marker="x");
hold off;
yticks([1 2 3]);
yticklabels({"1", "2", "3"});
legend("Imitation", "Exploitation", "Exploration");
